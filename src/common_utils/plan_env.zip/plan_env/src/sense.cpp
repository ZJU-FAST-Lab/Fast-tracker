#include <iostream>
#include <ros/ros.h>
#include <vector>
#include <ros/console.h>
#include <plan_env/grid_map.h>

int main(int argc, char **argv)
{
	ros::init(argc, argv, "sense_node");
    ros::NodeHandle nh("~");
	GridMap::Ptr grid_map_;
	grid_map_.reset(new GridMap);
  	grid_map_->initMap(nh);
	ros::Rate loop_rate(100);	//设置发送数据的频率为10Hz
	while(ros::ok())
	{
		ros::spinOnce();	//不是必须，若程序中订阅话题则必须，否则回掉函数不起作用。
		loop_rate.sleep();	//按前面设置的10Hz频率将程序挂起
	}
 
	return 0;
}