roslaunch traj_server real_traj_server.launch & sleep 2;
roslaunch grid_path_searcher real_tracker.launch & sleep 1;
roslaunch usb_cam 3_fisheye_real.launch & sleep 2;
roslaunch apriltags2_ros test.launch & sleep 2;
wait

